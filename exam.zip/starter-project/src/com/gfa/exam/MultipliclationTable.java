package com.gfa.exam;


public class MultipliclationTable {


    public static void main(String[] args) {


    }

    public static int multiplicationTable(int number) {
        for (int i = 1; i <= 10; i++) {
        int result = i * number;
            System.out.println(i + " * " + number + " = " + result);
        }


        return 1;


    }
}
