package com.gfa.exam;

public class Sum {

    public static void main(String[] args) {

    }

    public static int sum(int i) {
        int counter = 0;
        for (int j = 0; j <= i; j++) {
            counter += j;
            
        }
        return counter;

    }


}
