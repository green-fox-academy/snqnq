package com.gfa.exam;

public class AddDigits {
    public int addDigits(String input) {
        if (input == null || input.length() == 0) {
            return -1;
        }

        return input
                .codePoints()
                .mapToObj(c -> String.valueOf((char) c))
                .map(Integer::parseInt)
                .mapToInt(Integer::intValue)
                .sum();
    }
}